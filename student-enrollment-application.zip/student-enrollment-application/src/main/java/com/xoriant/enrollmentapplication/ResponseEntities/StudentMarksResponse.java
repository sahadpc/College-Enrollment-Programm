package com.xoriant.enrollmentapplication.ResponseEntities;



public class StudentMarksResponse {
	
	private int marksId;
	private double sscMarks;
	
	public int getMarksId() {
		return marksId;
	}
	public void setMarksId(int marksId) {
		this.marksId = marksId;
	}
	public double getSscMarks() {
		return sscMarks;
	}
	public void setSscMarks(double sscMarks) {
		this.sscMarks = sscMarks;
	}
	
	
}
