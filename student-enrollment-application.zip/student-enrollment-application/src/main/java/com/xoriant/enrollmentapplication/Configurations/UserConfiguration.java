package com.xoriant.enrollmentapplication.Configurations;

import org.springframework.context.annotation.Configuration;

@Configuration
public class UserConfiguration {
	
	/*
	 * @Bean 
	 * public PasswordEncoder encoder() 
	 * {
	 *  return new BCryptPasswordEncoder();
	 * }
	 */

}
