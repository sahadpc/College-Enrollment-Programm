package com.xoriant.enrollmentapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentEnrollmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
