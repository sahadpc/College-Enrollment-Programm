export class User {
    //userId!:String;
    firstname!:String;
    middlename!:String;
    lastname!:String;
    address!:string;
    city !:string;
    state !:string;
    pincode !:number;
    mobile !:number;
    email !:string;
    sscpercentage!:String;
    password!:string;
    confirmpassword!:string; 
}